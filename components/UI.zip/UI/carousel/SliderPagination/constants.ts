export const SLIDER_PAGINATION_BREAKPOINTS = {
  300: {
    slidesPerView: 20,
    spaceBetween: 4
  },
  768: {
    slidesPerView: 20,
    spaceBetween: 8
  }
}
