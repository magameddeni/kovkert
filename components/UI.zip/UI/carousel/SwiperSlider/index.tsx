export { default as SwiperSlider } from './SwiperSlider'
export * from 'swiper'
