export enum DeliveryOptions {
  ByCourier = 'Курьерская',
  Pickup = 'Самовывоз'
}
