export const defaultColumnMinWidth = 50

export const FEATURE_LIST_COLUMN_ID = 'features-list'
