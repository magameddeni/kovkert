export { default as Icon } from './Icon'
export type { IIconProps } from './Icon'
