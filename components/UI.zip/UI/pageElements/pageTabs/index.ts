export { default as PageTabs } from './PageTabs'
