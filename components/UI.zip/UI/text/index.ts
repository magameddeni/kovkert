export { default as Text } from './Text'
